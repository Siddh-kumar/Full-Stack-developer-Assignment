# AI Slides Assignment - Submission

This repository implements the assignment: a chat-based UI that uses the Gemini reasoning model to produce structured slide JSON and a frontend using pptxgenjs to generate .pptx files.

## Run locally
1. Clone the repo
2. Copy `.env.example` to `.env.local` and set `GEMINI_API_KEY`
3. `npm install`
4. `npm run dev`
5. Open `http://localhost:3000`

## Notes
- The server API route `/api/generate` is a placeholder; replace the endpoint with the real Gemini/Palm endpoint and ensure API key usage matches provider docs.
- Download button triggers `pptxgenjs` client-side to create a PPTX.

## Deployed link
- Deploy to Vercel and set environment variable `GEMINI_API_KEY`.
